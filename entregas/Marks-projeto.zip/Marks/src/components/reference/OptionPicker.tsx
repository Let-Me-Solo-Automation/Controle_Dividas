"use client";

import { useState, useRef, useEffect, type FC } from "react";
import { motion, AnimatePresence, MotionConfig } from "motion/react";
import { ChevronDown, Globe } from "lucide-react";
import { TbLockFilled } from "react-icons/tb";
import type { IconType } from "react-icons";
import { cn } from "../../lib/utils";

export interface Option {
  id: string;
  label: string;
  icon: IconType;
}

interface OptionPickerProps {
  options?: Option[];
  value?: string;
  onChange?: (id: string) => void;
  label?: string;
}

const DEFAULT_OPTIONS: Option[] = [
  { id: "private", label: "Private", icon: TbLockFilled },
  { id: "public", label: "Public", icon: Globe },
];

export const OptionPicker: FC<OptionPickerProps> = ({
  options,
  value,
  onChange,
  label = "Escolher opção",
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [localSelected, setSelected] = useState<Option>(
    options?.[0] || DEFAULT_OPTIONS[0],
  );
  const selected =
    (options || DEFAULT_OPTIONS).find((option) => option.id === value) ||
    localSelected;
  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    containerRef.current
      ?.querySelector<HTMLButtonElement>('button[aria-pressed="true"]')
      ?.focus({ preventScroll: true });
    const close = (restoreFocus: boolean) => {
      setIsOpen(false);
      if (restoreFocus) triggerRef.current?.focus({ preventScroll: true });
    };
    const outside = (event: PointerEvent) => {
      if (!containerRef.current?.contains(event.target as Node)) {
        const target = event.target instanceof Element ? event.target : null;
        close(!target?.closest("button,a,input,textarea,select,[tabindex]"));
      }
    };
    const keyboard = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        close(true);
      }
    };
    document.addEventListener("pointerdown", outside);
    document.addEventListener("keydown", keyboard, true);
    return () => {
      document.removeEventListener("pointerdown", outside);
      document.removeEventListener("keydown", keyboard, true);
    };
  }, [isOpen]);

  const toggleOpen = () => setIsOpen((prev) => !prev);
  const handleSelect = (option: Option) => {
    setSelected(option);
    onChange?.(option.id);
    setIsOpen(false);
    triggerRef.current?.focus({ preventScroll: true });
  };

  const data = options || DEFAULT_OPTIONS;

  return (
    <div
      className="relative inline-block perspective-[1200px] transform-3d"
      ref={containerRef}
    >
      <MotionConfig
        transition={{ type: "spring", damping: 20, stiffness: 300 }}
      >
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 7, filter: "blur(3px)", scale: 0.985 }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)", scale: 1 }}
              exit={{ opacity: 0, y: 5, filter: "blur(2px)", scale: 0.99 }}
              transition={{ type: "spring", stiffness: 300, damping: 28 }}
              className="option-picker-menu absolute bottom-full left-1/2 z-50 mb-2 origin-bottom -translate-x-1/2"
              role="menu"
              aria-label={label}
            >
              <div className="option-picker-panel relative flex gap-2 rounded-[20px] border border-neutral-100 bg-[#F3F3F3] p-2 dark:border-neutral-700 dark:bg-neutral-800">
                {data.map((option, index) => {
                  const isActive = selected.id === option.id;
                  const isFirst = index === 0;
                  const isLast = index === data.length - 1;

                  const roundedClasses = `
                    ${isFirst ? "rounded-l-full rounded-r-2xl" : ""}
                    ${isLast ? "rounded-r-full rounded-l-2xl" : ""}
                    ${!isFirst && !isLast ? "rounded-none" : ""}
                  `;

                  return (
                    <motion.button
                      key={option.id}
                      type="button"
                      aria-pressed={isActive}
                      onClick={() => handleSelect(option)}
                      whileTap={{ scale: 0.95 }}
                      whileHover={{ y: -1 }}
                      title={`Selecionar ${option.label}`}
                      aria-label={`Selecionar ${option.label}`}
                      className={`relative flex min-w-0 items-center gap-2 rounded-2xl px-4 py-3 text-left text-sm font-semibold transition-colors duration-200 ${roundedClasses} bg-[#FEFEFE] dark:bg-neutral-700 ${isActive ? "text-[#010101] dark:text-white" : "text-[#6E6E6E] dark:text-neutral-300"}`}
                    >
                      <motion.span>
                        <option.icon size={22} />
                      </motion.span>
                      <span className="relative z-10 min-w-0 whitespace-normal break-words text-sm">
                        {option.label}
                      </span>
                    </motion.button>
                  );
                })}

                <div className="absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 border-r border-b border-neutral-100 bg-[#F3F3F3] dark:border-neutral-700 dark:bg-neutral-800" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          ref={triggerRef}
          type="button"
          layout="size"
          aria-label={label}
          aria-expanded={isOpen}
          onClick={toggleOpen}
          whileTap={{ scale: 0.97 }}
          title={`${label}: ${selected.label}`}
          className={`flex items-center justify-center gap-2 rounded-full border border-transparent px-4 py-4 transition-all duration-300 select-none ${isOpen ? "bg-[#E5E5E5] dark:border-neutral-700 dark:bg-neutral-800" : "bg-[#F4F4F4] dark:bg-neutral-900"}`}
        >
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div
              key={selected.id}
              initial={{ opacity: 0, scale: 0.5, filter: "blur(4px)" }}
              animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, scale: 0.5, filter: "blur(4px)" }}
              className="flex items-center gap-2"
            >
              <selected.icon
                size={24}
                className={`transition-colors duration-300 ${isOpen ? "text-[#AEAEAE] dark:text-neutral-500" : "text-[#AFAFAF] dark:text-neutral-400"}`}
              />
            </motion.div>
          </AnimatePresence>
          <AnimatedText
            value={selected.label}
            className="text-lg font-semibold text-neutral-700 dark:text-neutral-100"
          />

          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            className="flex items-center"
          >
            <ChevronDown
              size={24}
              className={`transition-colors duration-300 ${isOpen ? "text-[#AEAEAE] dark:text-neutral-500" : "text-[#AFAFAF] dark:text-neutral-400"}`}
              strokeWidth={2.5}
            />
          </motion.div>
        </motion.button>
      </MotionConfig>
    </div>
  );
};

const AnimatedText = ({
  value,
  className,
}: {
  value: string;
  className?: string;
}) => {
  return (
    <div
      className={cn(
        "flex text-lg tracking-tight will-change-transform",
        className,
      )}
    >
      <AnimatePresence mode="popLayout" initial={false}>
        {value.split("").map((char, index) => {
          const displayChar = char === " " ? "\u00A0" : char;

          return (
            <motion.span
              key={char + index}
              layout
              initial={{ opacity: 0, y: 5, scale: 0.7 }}
              animate={{
                opacity: 1,
                y: 0,
                scale: 1,
                transition: {
                  type: "spring",
                  stiffness: 200,
                  damping: 20,
                  delay: 0.03 * index,
                },
              }}
              exit={{ opacity: 0, y: -5, scale: 0.7 }}
            >
              {displayChar}
            </motion.span>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
