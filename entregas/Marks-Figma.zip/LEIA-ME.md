# Marks no Figma

Importe o ZIP inteiro como projeto, mantendo os caminhos. Cada arquivo é menor que 1.000.000 bytes. Os módulos JS são carregados por demanda, sem cortar código ou recursos.

Esta exportação usa módulos JavaScript e precisa de HTTP/HTTPS, como o ambiente de prévia do Figma. Para testar localmente, nesta pasta execute python3 -m http.server 8765 e abra http://localhost:8765. Abrir index.html por file:// pode ser bloqueado pelo navegador. Para abrir diretamente sem servidor, use o pacote separado Marks-Visualizador.zip.

Dados de demonstração isolados em marks-figma-review-v1. Não contém registros pessoais. O ZIP completo pode ser maior que 1 MB; o limite é aplicado a cada arquivo individual.
