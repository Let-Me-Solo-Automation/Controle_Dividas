# Marks no Figma

Exportação estática do aplicativo React com interações. Abra index.html mantendo app.js e styles.css ao lado. HTML abaixo de 1 MB; os recursos são arquivos separados, necessários para funcionamento. Dados de demonstração isolados no armazenamento marks-figma-review-v1. Não contém registros pessoais.
